package com.ssafy.hw2.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.hw2.model.ItemVO;
import com.ssafy.hw2.service.GoodsService;

@Controller
@RequestMapping("/goods")
public class GoodsController {
	private static final Logger logger = LoggerFactory.getLogger(GoodsController.class);
	@Autowired
	GoodsService goodsService;
	
	@GetMapping("/register")
	public String register() {
		return "goods/register";
	}
	
	@PostMapping("/register")
	public String register(ItemVO item, RedirectAttributes redirectAttributest) throws Exception{
		logger.debug("register item: {}", item);
		goodsService.insert(item);
		redirectAttributest.addFlashAttribute("msg", "글작성 성공!!!");
		return "redirect:/goods/list";		
	}
	
	@GetMapping("/list")
	public ModelAndView list() throws Exception {
		ModelAndView mav = new ModelAndView();
		List<ItemVO> list = goodsService.list();
		System.out.println(list);
		mav.addObject("productList", list);
		mav.setViewName("goods/list");
		return mav;
	}
	
	@GetMapping("/modify")
	public ModelAndView modify(@RequestParam("seq") int seq) throws Exception {
		ModelAndView mav = new ModelAndView();
		ItemVO itemvo = goodsService.getItem(seq);
		mav.addObject("itemvo",itemvo);
		mav.setViewName("goods/modify");
		return mav;
	}
	
	@PostMapping("/modify")
	public String modify(ItemVO item, RedirectAttributes redirectAttributest) throws Exception{
		goodsService.modify(item);
		redirectAttributest.addFlashAttribute("msg", "글수정 성공!!!");
		return "redirect:/goods/list";		
	}
	
	@GetMapping("/login")
	public String login() throws Exception{
		return "goods/login";		
	}

	@PostMapping("/login")
	public String login(@RequestParam Map<String,String> map, HttpSession session,Model model) throws Exception{
		logger.debug("map:{}", map.get("userid"));
		String userid = (String) map.get("userid");
		try {
			if(goodsService.login(map)==1) {
				session.setAttribute("userinfo", userid);
				return "redirect:/";
			}else {
				model.addAttribute("msg", "아이디 또는 비밀번호가 일치하지 않습니다.");
				return "goods/login";
			}
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "로그인 중 문제 발생!!!");
			return "error/error";
		}	
	}
	@GetMapping("/logout")
	public String logout(HttpSession session) throws Exception{
		session.invalidate();
		return "redirect:/";		
	}
	
	@PostMapping("/delete")
	public String delete(String[] delch) throws Exception{
		List<String> del = Arrays.asList(delch);
		goodsService.delete(del);
		return "redirect:/goods/list";		
	}

}
