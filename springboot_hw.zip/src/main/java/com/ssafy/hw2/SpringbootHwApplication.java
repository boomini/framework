package com.ssafy.hw2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootHwApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHwApplication.class, args);
	}

}
