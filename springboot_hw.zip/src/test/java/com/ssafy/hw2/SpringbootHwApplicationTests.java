package com.ssafy.hw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
