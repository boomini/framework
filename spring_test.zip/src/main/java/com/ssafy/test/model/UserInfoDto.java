package com.ssafy.test.model;

public class UserInfoDto {

}
