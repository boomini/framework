package com.ssafy.hw2.model;

public class CateVO {
	int cate_seq;
	String cate_name;
	public int getCate_seq() {
		return cate_seq;
	}
	public void setCate_seq(int cate_seq) {
		this.cate_seq = cate_seq;
	}
	public String getCate_name() {
		return cate_name;
	}
	public void setCate_name(String cate_name) {
		this.cate_name = cate_name;
	}
	
}
