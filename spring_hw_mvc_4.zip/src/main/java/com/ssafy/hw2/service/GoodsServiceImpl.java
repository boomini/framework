package com.ssafy.hw2.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.hw2.dao.GoodsDAO;
import com.ssafy.hw2.model.CateVO;
import com.ssafy.hw2.model.ItemVO;

@Service
public class GoodsServiceImpl implements GoodsService{
	@Autowired
	GoodsDAO goodsdao;
	private GoodsServiceImpl(GoodsDAO goodsdao ) {
		this.goodsdao=goodsdao;
	}
	

	@Override
	public List<ItemVO> list() throws Exception {
		return goodsdao.list();
	}

	@Override
	public List<CateVO> listCate(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		return goodsdao.listCate(map);
	}

	@Override
	public void insert(ItemVO item) throws Exception {
		goodsdao.insert(item);
	}

	@Override
	public boolean modify(Map<String, Object> map) throws Exception {
		int status = goodsdao.modify(map);	
		return true;
	}


	@Override
	public ItemVO getItem(int seq) throws Exception {
		return goodsdao.getItem(seq);
	}


	@Override
	public boolean login(Map<String, String> map) throws Exception {
		return goodsdao.login(map);
	}

}
